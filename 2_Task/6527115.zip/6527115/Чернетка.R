install.packages("readr")
install.packages("moments")
library(moments)


# Завантажте бібліотеку для роботи з CSV
library(readr)

ethereum_data <- read_csv("Ethereum Historical Data.csv")
tsla_data <- read_csv("TSLA Historical Data.csv")
sony_data <- read_csv("SONY Historical Data.csv")

ethereum_price <- ethereum_data$Price
# Аналіз для Ethereum


# Максимальне та мінімальне значення
max_ethereum_price <- max(ethereum_price)
min_ethereum_price <- min(ethereum_price)

# Середнє значення (математичне сподівання)
mean_ethereum_price <- mean(ethereum_price)

# Стандартна похибка середнього
se_mean_ethereum_price <- sd(ethereum_price) / sqrt(length(ethereum_price))

# Медіана
median_ethereum_price <- median(ethereum_price)

# Мода (може бути кілька, якщо є однакові частоти)
mode_ethereum_price <- as.numeric(names(sort(table(ethereum_price), decreasing = TRUE)[1]))

# Дисперсія
variance_ethereum_price <- var(ethereum_price)

# Середньоквадратичне відхилення
sd_ethereum_price <- sd(ethereum_price)

# Коефіцієнти асиметрії та ексцесу
skewness_ethereum_price <- moments::skewness(ethereum_price)
kurtosis_ethereum_price <- moments::kurtosis(ethereum_price)

# Процентилі та квартилі
percentiles_ethereum_price <- quantile(ethereum_price, probs = c(0.25, 0.5, 0.75))
quartiles_ethereum_price <- quantile(ethereum_price, probs = c(0.25, 0.75))

# Інтерквартильний розмах
iqr_ethereum_price <- IQR(ethereum_price)

# Boxplot
boxplot(ethereum_price, main="Boxplot для Ethereum Price")

# Вивести результати для Ethereum
cat("Максимальне значення для Ethereum: ", max_ethereum_price, "\n")
cat("Мінімальне значення для Ethereum: ", min_ethereum_price, "\n")
cat("Середнє значення (математичне сподівання) для Ethereum: ", mean_ethereum_price, "\n")
cat("Стандартна похибка середнього для Ethereum: ", se_mean_ethereum_price, "\n")
cat("Медіана для Ethereum: ", median_ethereum_price, "\n")
cat("Мода для Ethereum: ", mode_ethereum_price, "\n")
cat("Дисперсія для Ethereum: ", variance_ethereum_price, "\n")
cat("Середньоквадратичне відхилення для Ethereum: ", sd_ethereum_price, "\n")
cat("Коефіцієнт асиметрії для Ethereum: ", skewness_ethereum_price, "\n")
cat("Коефіцієнт ексцесу для Ethereum: ", kurtosis_ethereum_price, "\n")
cat("25-й перцентиль для Ethereum: ", percentiles_ethereum_price[1], "\n")
cat("50-й перцентиль (медіана) для Ethereum: ", percentiles_ethereum_price[2], "\n")
cat("75-й перцентиль для Ethereum: ", percentiles_ethereum_price[3], "\n")
cat("Інтерквартильний розмах для Ethereum: ", iqr_ethereum_price, "\n")


# Аналіз для TSLA
tsla_price <- tsla_data$Price

# Максимальне та мінімальне значення
max_tsla_price <- max(tsla_price)
min_tsla_price <- min(tsla_price)

# Середнє значення (математичне сподівання)
mean_tsla_price <- mean(tsla_price)

# Стандартна похибка середнього
se_mean_tsla_price <- sd(tsla_price) / sqrt(length(tsla_price))

# Медіана
median_tsla_price <- median(tsla_price)

# Мода (може бути кілька, якщо є однакові частоти)
mode_tsla_price <- as.numeric(names(sort(table(tsla_price), decreasing = TRUE)[1]))

# Дисперсія
variance_tsla_price <- var(tsla_price)

# Середньоквадратичне відхилення
sd_tsla_price <- sd(tsla_price)

# Коефіцієнти асиметрії та ексцесу
skewness_tsla_price <- moments::skewness(tsla_price)
kurtosis_tsla_price <- moments::kurtosis(tsla_price)

# Процентилі та квартилі
percentiles_tsla_price <- quantile(tsla_price, probs = c(0.25, 0.5, 0.75))
quartiles_tsla_price <- quantile(tsla_price, probs = c(0.25, 0.75))

# Інтерквартильний розмах
iqr_tsla_price <- IQR(tsla_price)

# Boxplot
boxplot(tsla_price, main="Boxplot для TSLA Price")

# Вивести результати для TSLA
cat("Максимальне значення для TSLA: ", max_tsla_price, "\n")
cat("Мінімальне значення для TSLA: ", min_tsla_price, "\n")
cat("Середнє значення (математичне сподівання) для TSLA: ", mean_tsla_price, "\n")
cat("Стандартна похибка середнього для TSLA: ", se_mean_tsla_price, "\n")
cat("Медіана для TSLA: ", median_tsla_price, "\n")
cat("Мода для TSLA: ", mode_tsla_price, "\n")
cat("Дисперсія для TSLA: ", variance_tsla_price, "\n")
cat("Середньоквадратичне відхилення для TSLA: ", sd_tsla_price, "\n")
cat("Коефіцієнт асиметрії для TSLA: ", skewness_tsla_price, "\n")
cat("Коефіцієнт ексцесу для TSLA: ", kurtosis_tsla_price, "\n")
cat("25-й перцентиль для TSLA: ", percentiles_tsla_price[1], "\n")
cat("50-й перцентиль (медіана) для TSLA: ", percentiles_tsla_price[2], "\n")
cat("75-й перцентиль для TSLA: ", percentiles_tsla_price[3], "\n")
cat("Інтерквартильний розмах для TSLA: ", iqr_tsla_price, "\n")

